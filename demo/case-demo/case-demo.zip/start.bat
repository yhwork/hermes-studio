@echo off
title case-demo
echo Starting case-demo server...
echo.
node case-demo-serve.js %*
pause
