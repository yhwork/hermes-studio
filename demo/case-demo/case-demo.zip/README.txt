case-demo v1.0.0 — 测试用例生成 agent 便携包
========================================

要求：Node.js >= 18

启动方式：
  Windows:  双击 start.bat 或运行 node case-demo-serve.js
  Linux:    chmod +x start.sh && ./start.sh

默认端口 8792，环境变量覆盖：
  PORT=9100 node case-demo-serve.js

接入方式：
  HTTP REST:         POST http://localhost:8792/generate
  MCP HTTP:          http://localhost:8792/mcp
  MCP stdio:         node case-demo-mcp.js

可用工具：
  generate_cases   — 从需求文本/文档生成完整用例树（Markdown）
  edit_cases       — 按指令局部编辑用例树
  read_requirement — 读取 .docx/.xlsx/.txt/.md 需求文档
  validate_cases   — 校验用例树结构是否符合方法论
  export_xmind     — 导出为 .xmind 文件
  agent_chat       — 委派子 agent 多步处理
  agent_status     — 查看状态

LLM 模型配置（环境变量，或访问 /config 页面配置）：
  AGENT_MODEL_KEY      — LLM API key（或 OPENAI_API_KEY）
  AGENT_MODEL_BASE     — LLM base URL（或 OPENAI_BASE_URL）
  AGENT_MODEL_NAME     — LLM 模型名（或 OPENAI_MODEL）
  AGENT_MODEL_PROVIDER — provider（默认 openai）

也可直接继承 hermes 主 agent 的 config.yaml 配置（无需重复设置）。

Claude Code 配置（.mcp.json）：
  {
    "mcpServers": {
      "case-demo": {
        "command": "node",
        "args": ["path/to/case-demo-mcp.js"],
        "env": {
          "AGENT_MODEL_KEY": "sk-xxx",
          "AGENT_MODEL_BASE": "https://api.openai.com/v1",
          "AGENT_MODEL_NAME": "gpt-4o-mini"
        }
      }
    }
  }
