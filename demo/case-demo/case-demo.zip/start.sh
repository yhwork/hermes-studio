#!/bin/bash
echo "Starting case-demo server..."
echo
exec node case-demo-serve.js "$@"
