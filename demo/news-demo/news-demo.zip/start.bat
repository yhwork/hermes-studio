@echo off
title news-demo
echo Starting news-demo server...
echo.
node news-demo-serve.js %*
pause
