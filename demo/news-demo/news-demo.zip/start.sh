#!/bin/bash
echo "Starting news-demo server..."
echo
exec node news-demo-serve.js "$@"
