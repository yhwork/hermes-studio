news-demo v2.0.0 — 新闻热点 sub-agent 便携包
========================================

要求：Node.js >= 18

启动方式：
  Windows:  双击 start.bat 或运行 node news-demo-serve.js
  Linux:    chmod +x start.sh && ./start.sh

默认端口 8790，环境变量覆盖：
  PORT=9000 node news-demo-serve.js

接入方式：
  HTTP REST:         POST http://localhost:8790/hot
  MCP HTTP:          http://localhost:8790/mcp
  MCP stdio:         node news-demo-mcp.js

可用工具：
  hot_news       — 获取热搜（微博/知乎/百度/抖音/36氪）
  news_search    — 关键词搜索新闻
  news_summary   — 新闻摘要
  agent_chat     — 委派子 agent 分析
  agent_status   — 查看状态

Claude Code 配置（.mcp.json）：
  {
    "mcpServers": {
      "news-demo": {
        "command": "node",
        "args": ["path/to/news-demo-mcp.js"]
      }
    }
  }

环境变量（可选）：
  PORT              — HTTP 端口（默认 8790）
  HOST              — 监听地址（默认 0.0.0.0）
  AGENT_MODEL_KEY   — LLM API key（启用 AI 分析）
  AGENT_MODEL_BASE  — LLM API base URL
  AGENT_MODEL_NAME  — LLM 模型名
