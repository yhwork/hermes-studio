#!/bin/bash
echo "Starting vision-demo server..."
echo
exec node vision-demo-serve.js "$@"
