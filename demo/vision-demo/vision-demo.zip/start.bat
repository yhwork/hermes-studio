@echo off
title vision-demo
echo Starting vision-demo server...
echo.
node vision-demo-serve.js %*
pause
